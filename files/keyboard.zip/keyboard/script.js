let inputScreen = document.querySelector("#input")


// CHOOSE YOUR PASSWORD
const password = "BABA"

// CHOOSE YOUR MESSAGE
const message = "How did you know my password????"



// ADD KEYS HERE
let a = document.querySelector("#a")
a.onclick = function () {
    inputScreen.innerText = inputScreen.innerText + a.innerText
}

let b = document.querySelector("#b")
b.onclick = function () {
    inputScreen.innerText = inputScreen.innerText + b.innerText
}

let alex = document.querySelector("#alex")
alex.onclick = function () {
    inputScreen.innerText = inputScreen.innerText + alex.innerText
}

let moneyEmoji = document.querySelector("#money")
moneyEmoji.onclick = function () {
    inputScreen.innerText = inputScreen.innerText + moneyEmoji.innerText
}

let space = document.querySelector("#space")
space.onclick = function () {
    inputScreen.innerText = inputScreen.innerText + " "
}











// check password
let checkPassword = function () {
    if (inputScreen.innerText.includes(password)) {
        alert(message);
    }
}

document.querySelector("#password").onclick = function () {
    checkPassword();
}












// backspace
const backspaceButton = document.querySelector("#delete")
const backspace = function () {
    inputScreen.innerText = inputScreen.innerText.substring(0, inputScreen.innerText.length - 1)
}
backspaceButton.onclick = function () {
    backspace();
}