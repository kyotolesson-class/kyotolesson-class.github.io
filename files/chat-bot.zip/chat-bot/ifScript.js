let favoriteGame = prompt("What is your favorite game?")

if (favoriteGame === "Animal Crossing") {
    let favoriteAnimal = prompt("Wow, I love Animal Crossing too. Which is your favorite animal in Animal Crossing?")
    if (favoriteAnimal === "Tanukichi") {
        let numberOfBells = prompt("Oh yeah, I owe Tanukichi a lot of bells. How many bells do you owe Tanukichi?")
        if (numberOfBells === "1") {
            prompt("Oh, you are almost done! Nice.")
        }
        if (numberOfBells === "10000") {
            prompt("😱")
        }
    }
    if (favoriteAnimal === "Shizue") {
        prompt("Oh yeah, the yellow dog. She is fun to play in Smash Bros.")
    }
}
if (favoriteGame === "Fortnite") {
    let favoriteSkin = prompt("Fornite is AWESOME. What is your favorite skin?");

    if (favoriteSkin === "Drift") {
        prompt("What a cool fox mask.")
    }
    if (favoriteSkin === "Ironman") {
        prompt("Ironman is a Marvel character. Cool.")
    }
}