async function startGame() {
    // YOUR CODE BELOW 🚀
    dog.goTo(100, 0);

   forever(() => {
        vortex.turnClockwise(10)

        if(dog.isTouching('vortex')) {
            dog.turnClockwise()
            dog.say('wowowowoowowowoow', 1)
            playSound('meow.wav')
        }
    })

    whenPressed('right arrow', () => {
        dog.changeXBy(50)
    })

    whenPressed('left arrow', () => {
        dog.move(-50)
    })

    whenPressed('down arrow', () => {
        dog.changeYBy(-50)
    })

    whenPressed('up arrow', () => {
        dog.changeYBy(50)
    })

    dog.whenThisSpriteClicked(() => {
        playSound('meow.wav')
    })
}

startGame();